<?php

namespace App\Core;

class Error
{
	public function fileNotFound()
	{
		echo "<p>404 - File tidak ditemukan</p>";
	}
}
