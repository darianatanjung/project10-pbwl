<h2>Input Golongan</h2>

<form action="<?php echo URL; ?>/Golongan/save" method="post">
    <table>
        <tr>
            <td>KODE GOLONGAN</td>
            <td><input type="text" name="gol_kode" required></td>
        </tr>
        <tr>
            <td>NAMA</td>
            <td><input type="text" name="gol_nama" required></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_save" value="SAVE"></td>
        </tr>
    </table>
</form>